import {initializeApp} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {getAuth,onAuthStateChanged,createUserWithEmailAndPassword,signInWithEmailAndPassword,signOut,sendPasswordResetEmail,sendEmailVerification,deleteUser,reload} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {initializeFirestore,getFirestore,persistentLocalCache,persistentMultipleTabManager,collection,doc,setDoc,addDoc,updateDoc,deleteDoc,onSnapshot,query,where,orderBy,limit,arrayUnion,arrayRemove} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
const app=initializeApp({apiKey:"AIzaSyBYAw5mQ37a-_bek-57e_3u7lLVNJWI9dw",authDomain:"ficars-7c944.firebaseapp.com",projectId:"ficars-7c944",storageBucket:"ficars-7c944.firebasestorage.app",messagingSenderId:"348339596099",appId:"1:348339596099:web:1d29cf2549437c00f35df6"});
const auth=getAuth(app);let store;
try{store=initializeFirestore(app,{localCache:persistentLocalCache({tabManager:persistentMultipleTabManager()})})}catch(e){store=getFirestore(app)}
const U=u=>u?{uid:u.uid,email:u.email,emailVerified:u.emailVerified}:null;
const fb={auth:{
 onChange:cb=>onAuthStateChanged(auth,u=>cb(U(u))),
 signUp:async(e,p)=>U((await createUserWithEmailAndPassword(auth,e,p)).user),
 signIn:async(e,p)=>U((await signInWithEmailAndPassword(auth,e,p)).user),
 signOut:()=>signOut(auth),reset:e=>sendPasswordResetEmail(auth,e),verify:()=>sendEmailVerification(auth.currentUser),
 reload:async()=>{await reload(auth.currentUser);await auth.currentUser.getIdToken(true);return U(auth.currentUser)},
 deleteUser:()=>deleteUser(auth.currentUser)},
 db:{set:(c,i,d,m)=>setDoc(doc(store,c,i),d,m?{merge:true}:{}),
  add:async(c,d)=>(await addDoc(collection(store,c),d)).id,
  patch:(c,i,p)=>{const o={};for(const k in p){const v=p[k];o[k]=v&&typeof v==='object'&&('add' in v||'remove' in v)?('add' in v?arrayUnion(v.add):arrayRemove(v.remove)):v}return updateDoc(doc(store,c,i),o)},
  del:(c,i)=>deleteDoc(doc(store,c,i)),
  listen:(c,s,cb,eb)=>{const q=[collection(store,c)];(s.where||[]).forEach(w=>q.push(where(...w)));if(s.order)q.push(orderBy(...s.order));if(s.limit)q.push(limit(s.limit));
   return onSnapshot(query(...q),sn=>cb(sn.docs.map(d=>({id:d.id,...d.data()}))),eb)}}};
window.Core=FicarsCore.makeCore(fb);
const s=document.createElement('script');s.src='app.js';document.body.appendChild(s);
