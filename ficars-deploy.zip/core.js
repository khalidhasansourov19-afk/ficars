(function(g){'use strict';
const DAY=864e5,CFG={allowedDomain:''}; // set to e.g. 'youruniversity.edu' to limit sign-up
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=p=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const err=e=>({ok:false,error:e});
const okImg=s=>typeof s==='string'&&/^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(s)?s:'';
const MSG={'auth/invalid-credential':'Wrong email or password.','auth/wrong-password':'Wrong email or password.','auth/user-not-found':'Wrong email or password.','auth/invalid-email':'Enter a valid email address.','auth/email-already-in-use':'This email already has an account. Log in instead.','auth/weak-password':'Password needs at least 8 characters.','auth/too-many-requests':'Too many attempts. Wait a few minutes and try again.','auth/network-request-failed':'No internet connection. Try again.','auth/requires-recent-login':'For safety, log out, log in again, then retry.','permission-denied':'Not allowed. Verify your email first, then try again.','unavailable':'No connection to the server. Try again.'};
const nice=e=>{const c=String(e&&e.code||'').replace(/^firestore\//,'');return MSG[c]||'Something went wrong. Check your connection and try again.'};
function ago(t){const s=(Date.now()-t)/1e3;if(s<60)return 'Just now';if(s<3600)return Math.floor(s/60)+' min ago';if(s<86400)return Math.floor(s/3600)+' h ago';return Math.floor(s/86400)+' d ago'}
const clock=t=>new Date(t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
function avatarOf(u){if(u.avatar)return u.avatar;let h=0;for(const c of u.name)h=(h*31+c.codePointAt(0))%360;
 const ch=esc((Array.from(u.name.trim())[0]||'?').toUpperCase());
 return 'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" fill="hsl('+h+' 45% 38%)"/><text x="40" y="53" font-size="36" text-anchor="middle" fill="#fff" font-family="sans-serif">'+ch+'</text></svg>')}
const H={esc,okImg,ago,clock,avatarOf,CFG};
function makeCore(fb){
 const A=fb.auth,F=fb.db,db={users:[],posts:[],stories:[],msgs:[],notifs:[],blocks:[]},blk={by:[],who:[]};
 let cur=null,ready=false,started=null,subs=[],cbs=[],ecbs=[],rcbs=[],timer=0;
 const emit=()=>{if(!timer)timer=setTimeout(()=>{timer=0;cbs.forEach(f=>f())},0)};
 const fail=e=>{const m=nice(e);ecbs.forEach(f=>f(m))};
 const W=f=>{try{Promise.resolve(f()).catch(fail)}catch(e){fail(e)}return {ok:true}};
 const sid=()=>cur?cur.uid:null;
 function stop(){subs.forEach(u=>u());subs=[];started=null;for(const k in db)db[k]=[];blk.by=[];blk.who=[]}
 function start(id){if(started===id)return;stop();started=id;
  const on=(c,s,f)=>subs.push(F.listen(c,s,d=>{f(d);emit()},fail));
  on('users',{},d=>db.users=d);
  on('posts',{order:['t','desc'],limit:100},d=>db.posts=d.map(p=>Object.assign({},p,{likes:p.likes||[],comments:p.comments||[]})));
  on('stories',{where:[['t','>',Date.now()-DAY]]},d=>db.stories=d);
  on('msgs',{where:[['participants','array-contains',id]]},d=>db.msgs=d);
  on('notifs',{where:[['to','==',id]]},d=>db.notifs=d);
  on('blocks',{where:[['by','==',id]]},d=>blk.by=d);
  on('blocks',{where:[['who','==',id]]},d=>blk.who=d)}
 A.onChange(u=>{cur=u;if(u)start(u.uid);else stop();if(!ready){ready=true;rcbs.forEach(f=>f())}emit()});
 const pub=u=>({id:u.id,name:u.name||'Student',avatar:u.avatar||'',cover:u.cover||'',joined:u.joined||0});
 const me=()=>{if(!cur)return null;const u=db.users.find(x=>x.id===cur.uid)||{id:cur.uid,name:String(cur.email||'').split('@')[0]};return Object.assign(pub(u),{email:cur.email,verified:!!cur.emailVerified})};
 const user=id=>{const u=db.users.find(x=>x.id===id);return u?pub(u):(id===sid()?me():{id,name:'Deleted user',avatar:'',cover:''})};
 const hidden=id=>blk.by.some(b=>b.who===id)||blk.who.some(b=>b.by===id);
 const gate=()=>{const m=me();return !m?err('Log in first.'):!m.verified?err('Verify your email first. We sent you a link.'):null};
 const okEmail=e=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
 async function signup(name,email,pw){
  name=String(name).trim().replace(/\s+/g,' ');email=String(email).trim().toLowerCase();pw=String(pw);
  if(name.length<2||name.length>40)return err('Enter your name (2–40 characters).');
  if(!okEmail(email))return err('Enter a valid email address.');
  if(CFG.allowedDomain&&!email.endsWith('@'+CFG.allowedDomain))return err('Use your @'+CFG.allowedDomain+' email.');
  if(pw.length<8)return err('Password needs at least 8 characters.');
  try{const u=await A.signUp(email,pw);cur=u;start(u.uid);
   await F.set('users',u.uid,{name,avatar:'',cover:'',joined:Date.now()});
   try{await A.verify()}catch(e){}
   emit();return {ok:true}}catch(e){return err(nice(e))}}
 async function login(email,pw){try{const u=await A.signIn(String(email).trim().toLowerCase(),String(pw));cur=u;start(u.uid);emit();return {ok:true}}catch(e){return err(nice(e))}}
 async function logout(){try{await A.signOut()}catch(e){}}
 async function resetPassword(email){email=String(email).trim().toLowerCase();if(!okEmail(email))return err('Enter a valid email address.');
  try{await A.reset(email)}catch(e){if(e&&e.code!=='auth/user-not-found')return err(nice(e))}
  return {ok:true,message:'If this email has an account, a reset link is on its way.'}}
 async function resendVerify(){try{await A.verify();return {ok:true}}catch(e){return err(nice(e))}}
 async function checkVerified(){try{cur=await A.reload();emit();return !!(cur&&cur.emailVerified)}catch(e){return false}}
 function addPost(text,image){const x=gate();if(x)return x;const u=me();text=String(text||'').trim().slice(0,2000);const img=okImg(image);
  if(!text&&!img)return err('Write something or add a photo.');
  return W(()=>F.add('posts',{uid:u.id,text,image:img,t:Date.now(),likes:[],comments:[]}))}
 const feed=()=>db.posts.filter(p=>!hidden(p.uid)).sort((a,b)=>b.t-a.t);
 const post=id=>db.posts.find(p=>p.id===id&&!hidden(p.uid));
 function like(id){const x=gate();if(x)return x;const u=me(),p=post(id);if(!p)return err('Post not found.');
  const on=!p.likes.includes(u.id),nid='like_'+id+'_'+u.id;
  W(()=>F.patch('posts',id,{likes:on?{add:u.id}:{remove:u.id}}));
  if(on&&p.uid!==u.id)W(()=>F.set('notifs',nid,{to:p.uid,from:u.id,type:'like',pid:id,t:Date.now(),read:false}));
  if(!on)Promise.resolve().then(()=>F.del('notifs',nid)).catch(()=>{});
  return {ok:true,liked:on}}
 function comment(id,text){const x=gate();if(x)return x;const u=me(),p=post(id);text=String(text||'').trim().slice(0,500);
  if(!p)return err('Post not found.');if(!text)return err('Write a comment first.');
  W(()=>F.patch('posts',id,{comments:{add:{id:uid('c'),uid:u.id,text,t:Date.now()}}}));
  if(p.uid!==u.id)W(()=>F.add('notifs',{to:p.uid,from:u.id,type:'comment',pid:id,t:Date.now(),read:false}));
  return {ok:true}}
 function delPost(id){const u=me(),p=db.posts.find(x=>x.id===id);if(!u||!p||p.uid!==u.id)return err('You can only delete your own posts.');return W(()=>F.del('posts',id))}
 function report(kind,id,reason){const u=me();if(!u)return err('Log in first.');return W(()=>F.add('reports',{by:u.id,kind,target:id,reason:String(reason).slice(0,60),t:Date.now()}))}
 function block(who){const u=me();if(!u||who===u.id)return err('You cannot block this account.');return W(()=>F.set('blocks',u.id+'_'+who,{by:u.id,who}))}
 function addStory(text,bg,image){const x=gate();if(x)return x;const u=me();text=String(text||'').trim().slice(0,140);const img=okImg(image);
  if(!text&&!img)return err('Add text or a photo.');
  return W(()=>F.add('stories',{uid:u.id,text,bg:Math.max(0,Math.min(3,+bg||0)),image:img,t:Date.now()}))}
 const stories=()=>db.stories.filter(s=>s.t>Date.now()-DAY&&!hidden(s.uid)).sort((a,b)=>b.t-a.t);
 function send(to,text,image){const x=gate();if(x)return x;const u=me();text=String(text||'').trim().slice(0,1000);const img=okImg(image);
  if(to===u.id||!db.users.some(y=>y.id===to)||hidden(to))return err('You cannot message this person.');
  if(!text&&!img)return err('Type a message first.');
  return W(()=>F.add('msgs',{from:u.id,to,participants:[u.id,to],text,image:img,t:Date.now(),read:false}))}
 const thread=o=>{const m=me();return m?db.msgs.filter(x=>(x.from===m.id&&x.to===o)||(x.from===o&&x.to===m.id)).sort((a,b)=>a.t-b.t):[]};
 function markRead(o){const m=me();if(!m)return;db.msgs.filter(x=>x.from===o&&x.to===m.id&&!x.read).forEach(x=>W(()=>F.patch('msgs',x.id,{read:true})))}
 const unreadMsgs=()=>{const m=me();return m?db.msgs.filter(x=>x.to===m.id&&!x.read&&!hidden(x.from)).length:0};
 function chats(){const m=me();if(!m)return [];const last={};
  db.msgs.forEach(x=>{const o=x.from===m.id?x.to:x.from;if(!last[o]||x.t>=last[o].t)last[o]=x});
  return Object.keys(last).filter(o=>!hidden(o)).map(o=>({user:user(o),last:last[o],unread:db.msgs.filter(x=>x.from===o&&x.to===m.id&&!x.read).length})).sort((a,b)=>b.last.t-a.last.t)}
 const people=()=>db.users.filter(x=>x.id!==sid()&&!hidden(x.id)).map(pub);
 function share(pid,to){const p=post(pid);if(!p)return err('Post not found.');return send(to,'Shared a post by '+user(p.uid).name+': '+(p.text.slice(0,120)||'(photo)'),'')}
 const notifs=()=>db.notifs.filter(n=>!hidden(n.from)).sort((a,b)=>b.t-a.t);
 const unreadNotifs=()=>notifs().filter(n=>!n.read).length;
 function readAll(){db.notifs.filter(n=>!n.read).forEach(n=>W(()=>F.patch('notifs',n.id,{read:true})))}
 function search(q){q=String(q).trim().toLowerCase();if(!q)return {users:[],posts:[]};
  return {users:people().filter(u=>u.name.toLowerCase().includes(q)).slice(0,8),posts:feed().filter(p=>p.text.toLowerCase().includes(q)).slice(0,8)}}
 function updateProfile(o){const m=me();if(!m)return err('Log in first.');
  const n=String(o.name==null?m.name:o.name).trim().replace(/\s+/g,' ');if(n.length<2||n.length>40)return err('Enter your name (2–40 characters).');
  const d={name:n},a=okImg(o.avatar),c=okImg(o.cover);if(a)d.avatar=a;if(c)d.cover=c;
  return W(()=>F.set('users',m.id,d,true))}
 async function deleteAccount(){const u=me();if(!u)return err('Log in first.');
  try{const ops=[];
   db.posts.forEach(p=>{if(p.uid===u.id)ops.push(F.del('posts',p.id));else{
    if(p.likes.includes(u.id)){ops.push(F.patch('posts',p.id,{likes:{remove:u.id}}));ops.push(F.del('notifs','like_'+p.id+'_'+u.id).catch(()=>{}))}
    p.comments.filter(c=>c.uid===u.id).forEach(c=>ops.push(F.patch('posts',p.id,{comments:{remove:c}})))}});
   db.stories.filter(s=>s.uid===u.id).forEach(s=>ops.push(F.del('stories',s.id)));
   db.msgs.filter(m=>m.from===u.id).forEach(m=>ops.push(F.del('msgs',m.id)));
   db.notifs.forEach(n=>ops.push(F.del('notifs',n.id)));
   blk.by.forEach(b=>ops.push(F.del('blocks',b.id)));
   await Promise.all(ops);await F.del('users',u.id);await A.deleteUser();return {ok:true}}
  catch(e){return err(nice(e))}}
 return Object.assign({init:()=>{},signup,login,logout,resetPassword,resendVerify,checkVerified,me,user,addPost,feed,like,comment,delPost,report,block,addStory,stories,send,thread,markRead,unreadMsgs,chats,people,share,notifs,unreadNotifs,readAll,search,updateProfile,deleteAccount,
  onChange:f=>cbs.push(f),onError:f=>ecbs.push(f),onReady:f=>ready?f():rcbs.push(f)},H)}
g.FicarsCore=Object.assign({makeCore},H);
if(typeof module!=='undefined')module.exports=g.FicarsCore;
})(typeof globalThis!=='undefined'?globalThis:window);
