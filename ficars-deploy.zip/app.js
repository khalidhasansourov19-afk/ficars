(function(){'use strict';
const C=Core,E=C.esc,$=s=>document.querySelector(s);
const S={v:'feed',chat:null,uid:null,tab:'posts',notif:false,q:'',auth:'in',pimg:'',sp:null,rep:null,tm:0},D={};let ready=false;
const BG=['linear-gradient(135deg,#0f766e,#134e4a)','linear-gradient(135deg,#d97706,#7c2d12)','linear-gradient(135deg,#7c3aed,#312e81)','linear-gradient(135deg,#db2777,#4c0519)'];
const P={home:'M3 11l9-8 9 8M5 10v10h14V10',chat:'M4 5h16v11H9l-5 4z',user:'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 4-6 8-6s8 2 8 6',bell:'M6 17V11a6 6 0 1112 0v6l2 2H4zM10 21h4',heart:'M12 20s-8-5-8-11a4.5 4.5 0 018-2.5A4.5 4.5 0 0120 9c0 6-8 11-8 11z',comment:'M21 12a8 8 0 01-11.5 7.2L4 20l1-4.5A8 8 0 1121 12z',share:'M4 12l16-8-6 16-3-7z',moon:'M20 14A8 8 0 0110 4a8 8 0 1010 10z',plus:'M12 5v14M5 12h14',x:'M6 6l12 12M18 6L6 18',trash:'M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13',flag:'M5 21V4h12l-2 4 2 4H5',image:'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4'};
const i=n=>'<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+P[n]+'"/></svg>';
let tt;const toast=m=>{const t=$('#toast');t.textContent=m;t.className='on';clearTimeout(tt);tt=setTimeout(()=>t.className='',3200)};
const modal=(h,c)=>{$('#modal').innerHTML='<div class="ov" data-act="ovl"><div class="box '+(c||'')+'" role="dialog" aria-modal="true">'+h+'</div></div>'};
const closeModal=()=>{clearTimeout(S.tm);$('#modal').innerHTML=''};
const bgOf=s=>s.image?"center/cover url('"+s.image+"')":BG[s.bg];
function setTheme(t){document.documentElement.dataset.theme=t;try{localStorage.setItem('ficars_theme',t)}catch(e){}}
function shrink(f,max){return new Promise((ok,no)=>{if(!f||!/^image\//.test(f.type))return no(new Error('Choose an image file.'));
 const im=new Image(),u=URL.createObjectURL(f);im.onload=()=>{const k=Math.min(1,(max||800)/Math.max(im.width,im.height)),c=document.createElement('canvas');
 c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);ok(c.toDataURL('image/jpeg',.72))};
 im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('Could not read this image.'))};im.src=u})}
function reset(){Object.assign(S,{v:'feed',chat:null,uid:null,tab:'posts',notif:false,q:'',auth:'in',pimg:''});for(const k in D)delete D[k]}
function authScreen(){const m=S.auth,up=m==='up';
 const form=m==='reset'?'<h2>Reset password</h2><form data-form="reset"><label>Email<input name="email" type="email" autocomplete="email" required></label><p class="err" id="aerr" role="alert"></p><button class="btn full">Send reset link</button></form><p class="hint"><button class="btn ghost sm" data-act="auth" data-id="in">Back to log in</button></p>'
 :'<div class="seg"><button data-act="auth" data-id="in" class="'+(up?'':'on')+'">Log in</button><button data-act="auth" data-id="up" class="'+(up?'on':'')+'">Sign up</button></div><form data-form="'+(up?'signup':'login')+'">'+(up?'<label>Full name<input name="name" autocomplete="name" required maxlength="40"></label>':'')+'<label>Email<input name="email" type="email" autocomplete="email" required></label><label>Password<input name="pw" type="password" autocomplete="'+(up?'new-password':'current-password')+'" minlength="'+(up?8:1)+'" required></label><p class="err" id="aerr" role="alert"></p><button class="btn full">'+(up?'Create account':'Log in')+'</button></form>'+(up?'<p class="hint">We will email you a link to verify your address. You can report or block anyone, and delete your account any time.</p>':'<p class="hint"><button class="btn ghost sm" data-act="forgot">Forgot password?</button></p>');
 $('#app').innerHTML='<main class="auth"><h1 class="logo">Ficars</h1><p>Your campus, in one place.</p><div class="card">'+form+'</div></main>'}
function shell(){return '<header class="top"><b class="logo">Ficars</b><input id="q" type="search" class="srch" placeholder="Search Ficars" autocomplete="off" aria-label="Search"><button data-act="theme" aria-label="Switch theme">'+i('moon')+'</button><button data-act="bell" class="rel" aria-label="Notifications">'+i('bell')+'<span class="dot" id="nb" hidden></span></button></header><div id="vb" class="top2"></div><div id="sr" class="top2"></div><div id="np" class="top2"></div><main id="main"></main><nav class="tabs"><button data-act="go" data-id="feed">'+i('home')+'Home</button><button data-act="go" data-id="chats" class="rel">'+i('chat')+'Chats<span class="dot" id="mb" hidden></span></button><button data-act="go" data-id="profile">'+i('user')+'Me</button></nav>'}
function card(p,me){const u=C.user(p.uid),l=p.likes.includes(me.id);
 return '<article class="card" id="p-'+p.id+'"><header class="ph"><button class="who" data-act="user" data-id="'+u.id+'"><img src="'+C.avatarOf(u)+'" alt=""><span><b>'+E(u.name)+'</b><small>'+C.ago(p.t)+'</small></span></button>'+(p.uid===me.id?'<button data-act="delpost" data-id="'+p.id+'" aria-label="Delete post">'+i('trash')+'</button>':'<button data-act="report" data-kind="post" data-id="'+p.id+'" aria-label="Report post">'+i('flag')+'</button>')+'</header>'+(p.text?'<p class="tx">'+E(p.text)+'</p>':'')+(p.image?'<img class="pimg" src="'+p.image+'" alt="Photo posted by '+E(u.name)+'">':'')+'<div class="acts"><button data-act="like" data-id="'+p.id+'" class="'+(l?'on':'')+'" aria-pressed="'+l+'">'+i('heart')+p.likes.length+'</button><button data-act="focus" data-id="'+p.id+'">'+i('comment')+p.comments.length+'</button><button data-act="share" data-id="'+p.id+'">'+i('share')+'Share</button></div><div class="cm">'+p.comments.map(c=>'<p><b>'+E(C.user(c.uid).name)+'</b> '+E(c.text)+'</p>').join('')+'</div><form data-form="comment" data-id="'+p.id+'" class="row"><input name="t" data-draft="c-'+p.id+'" maxlength="500" placeholder="Write a comment" aria-label="Comment"><button class="btn sm">Send</button></form></article>'}
const V={
feed(me){return '<section class="stories"><button class="st add" data-act="newstory">'+i('plus')+'<span>Add story</span></button>'+C.stories().map(s=>{const u=C.user(s.uid);return '<button class="st" data-act="story" data-id="'+s.id+'" style="background:'+bgOf(s)+'"><img src="'+C.avatarOf(u)+'" alt=""><span>'+E(u.name.split(' ')[0])+'</span><i class="stx">'+E(s.text.slice(0,40))+'</i></button>'}).join('')+'</section><section class="card"><textarea data-draft="post" rows="3" maxlength="2000" placeholder="Share something with campus" aria-label="New post"></textarea>'+(S.pimg?'<div class="prev"><img src="'+S.pimg+'" alt="Selected photo"><button data-act="rmimg" aria-label="Remove photo">'+i('x')+'</button></div>':'')+'<div class="row"><label class="btn ghost" style="margin:0">'+i('image')+' Photo<input type="file" id="pfile" accept="image/*" hidden></label><button class="btn" data-act="post">Post</button></div></section>'+(C.feed().map(p=>card(p,me)).join('')||'<p class="empty">No posts yet. Be the first to share something.</p>')},
chats(me){if(S.chat){const o=C.user(S.chat),th=C.thread(S.chat);
 return '<section class="card chat"><header class="ph"><button class="btn ghost sm" data-act="back">Back</button><button class="who" data-act="user" data-id="'+o.id+'"><img src="'+C.avatarOf(o)+'" alt=""><b>'+E(o.name)+'</b></button></header><div class="msgs" id="msgs">'+(th.map(m=>'<div class="m '+(m.from===me.id?'me':'')+'">'+(m.text?E(m.text):'')+(m.image?'<img src="'+m.image+'" alt="Photo">':'')+'<small>'+C.clock(m.t)+'</small></div>').join('')||'<p class="empty">No messages yet. Say hello.</p>')+'</div><form data-form="msg" class="row"><label class="btn ghost" style="margin:0" aria-label="Send photo">'+i('image')+'<input type="file" id="mfile" accept="image/*" hidden></label><input name="t" data-draft="msg" maxlength="1000" placeholder="Type a message" aria-label="Message"><button class="btn sm">Send</button></form></section>'}
 const cs=C.chats(),pp=C.people();
 return '<section class="card"><h2>Chats</h2>'+(cs.map(c=>'<button class="who row-b" data-act="chat" data-id="'+c.user.id+'"><img src="'+C.avatarOf(c.user)+'" alt=""><span><b>'+E(c.user.name)+'</b><small>'+E((c.last.text||'Photo').slice(0,50))+'</small></span>'+(c.unread?'<span class="dot s">'+c.unread+'</span>':'')+'</button>').join('')||'<p class="empty">No conversations yet.</p>')+'</section><section class="card"><h2>People</h2>'+(pp.map(u=>'<button class="who row-b" data-act="chat" data-id="'+u.id+'"><img src="'+C.avatarOf(u)+'" alt=""><b>'+E(u.name)+'</b></button>').join('')||'<p class="empty">No one else has joined yet. Invite your classmates.</p>')+'</section>'},
profile(me){const u=C.user(S.uid||me.id),own=u.id===me.id,ps=C.feed().filter(p=>p.uid===u.id);
 return '<section class="card"><div class="cover" style="'+(u.cover?"background:center/cover url('"+u.cover+"')":'')+'"></div><div class="pi"><img class="big" src="'+C.avatarOf(u)+'" alt=""><div><h1>'+E(u.name)+'</h1><small>'+ps.length+' posts</small></div></div><div class="row wrap">'+(own?'<button class="btn" data-act="edit">Edit profile</button>':'<button class="btn" data-act="chat" data-id="'+u.id+'">Message</button><button class="btn ghost" data-act="block" data-id="'+u.id+'">Block</button><button class="btn ghost" data-act="report" data-kind="user" data-id="'+u.id+'">Report</button>')+'</div><div class="seg"><button data-act="tab" data-id="posts" class="'+(S.tab==='posts'?'on':'')+'">Posts</button><button data-act="tab" data-id="photos" class="'+(S.tab==='photos'?'on':'')+'">Photos</button></div></section>'+(S.tab==='photos'?'<div class="grid">'+(ps.filter(p=>p.image).map(p=>'<img src="'+p.image+'" alt="">').join('')||'<p class="empty">No photos yet.</p>')+'</div>':ps.map(p=>card(p,me)).join('')||'<p class="empty">No posts yet.</p>')+(own?'<section class="card"><h2>Settings</h2><div class="row wrap"><button class="btn ghost" data-act="theme">Switch theme</button><button class="btn ghost" data-act="logout">Log out</button><button class="btn danger" data-act="delacc">Delete account</button></div></section>':'')}};
function sr(){const r=S.q.trim()?C.search(S.q):null;$('#sr').innerHTML=r?'<div class="card">'+r.users.map(u=>'<button class="who" data-act="user" data-id="'+u.id+'"><img src="'+C.avatarOf(u)+'" alt=""><b>'+E(u.name)+'</b></button>').join('')+r.posts.map(p=>'<button class="who" data-act="hit" data-id="'+p.id+'"><span><b>'+E(p.text.slice(0,80))+'</b><small>by '+E(C.user(p.uid).name)+'</small></span></button>').join('')+(r.users.length||r.posts.length?'':'<p class="empty">No matches.</p>')+'</div>':''}
function notifPanel(){const l=C.notifs().slice(0,20);return '<div class="card"><div class="row"><b>Notifications</b><button class="btn ghost sm" data-act="readall">Mark all read</button></div>'+(l.map(n=>'<p class="'+(n.read?'':'unr')+'">'+E(C.user(n.from).name)+' '+(n.type==='like'?'liked':'commented on')+' your post. <small>'+C.ago(n.t)+'</small></p>').join('')||'<p class="empty">Nothing new yet.</p>')+'</div>'}
const scrollMsgs=()=>{const m=$('#msgs');if(m)m.scrollTop=m.scrollHeight};
function refresh(){if(!ready)return;const me=C.me();if(!me){authScreen();return}
 const ae=document.activeElement,key=ae&&ae.dataset&&ae.dataset.draft,ss=ae&&ae.selectionStart,se=ae&&ae.selectionEnd;
 if(!$('#main'))$('#app').innerHTML=shell();
 $('#main').innerHTML=V[S.v](me);
 document.querySelectorAll('[data-draft]').forEach(el=>{el.value=D[el.dataset.draft]||''});
 if(key){const el=document.querySelector('[data-draft="'+key+'"]');if(el){el.focus();try{el.setSelectionRange(ss,se)}catch(x){}}}
 document.querySelectorAll('.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.id===S.v));
 const nu=C.unreadNotifs(),mu=C.unreadMsgs();$('#nb').textContent=nu;$('#nb').hidden=!nu;$('#mb').textContent=mu;$('#mb').hidden=!mu;
 $('#vb').innerHTML=me.verified?'':'<div class="card"><b>Verify your email</b><p class="hint">We sent a link to '+E(me.email)+'. Open it, then tap the button below.</p><div class="row wrap"><button class="btn sm" data-act="checkv">I verified</button><button class="btn ghost sm" data-act="resend">Resend email</button></div></div>';
 $('#np').innerHTML=S.notif?notifPanel():'';sr();scrollMsgs()}
function viewStory(id){const s=C.stories().find(x=>x.id===id);if(!s)return;const u=C.user(s.uid);
 modal('<div class="sv" style="background:'+bgOf(s)+'"><i class="bar"></i><header class="who"><img src="'+C.avatarOf(u)+'" alt=""><span><b>'+E(u.name)+'</b><small>'+C.ago(s.t)+'</small></span><button data-act="close" aria-label="Close">'+i('x')+'</button></header><p>'+E(s.text)+'</p></div>','flush');S.tm=setTimeout(closeModal,5000)}
const peopleBtns=a=>C.people().map(u=>'<button class="who" data-act="'+a+'" data-id="'+u.id+'"><img src="'+C.avatarOf(u)+'" alt=""><b>'+E(u.name)+'</b></button>').join('')||'<p class="empty">No one else has joined yet.</p>';
document.addEventListener('click',async e=>{const t=e.target.closest('[data-act]');if(!t)return;const a=t.dataset.act,id=t.dataset.id;let r;
 switch(a){
 case 'ovl':if(e.target===t)closeModal();break;
 case 'close':closeModal();break;
 case 'theme':setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');break;
 case 'auth':S.auth=id;authScreen();break;
 case 'go':S.v=id;S.chat=null;S.uid=null;S.tab='posts';S.notif=false;refresh();window.scrollTo(0,0);break;
 case 'bell':S.notif=!S.notif;refresh();break;
 case 'readall':C.readAll();refresh();break;
 case 'user':S.v='profile';S.uid=id===C.me().id?null:id;S.tab='posts';S.q='';$('#q').value='';S.notif=false;refresh();window.scrollTo(0,0);break;
 case 'hit':S.q='';$('#q').value='';S.v='feed';S.chat=null;refresh();{const el=document.getElementById('p-'+id);if(el)el.scrollIntoView()}break;
 case 'tab':S.tab=id;refresh();break;
 case 'post':r=C.addPost(D.post,S.pimg);if(r.ok){D.post='';S.pimg=''}else toast(r.error);refresh();break;
 case 'rmimg':S.pimg='';refresh();break;
 case 'like':r=C.like(id);if(!r.ok)toast(r.error);refresh();break;
 case 'focus':{const el=document.querySelector('[data-draft="c-'+id+'"]');if(el)el.focus();break}
 case 'delpost':if(confirm('Delete this post?')){r=C.delPost(id);if(!r.ok)toast(r.error);refresh()}break;
 case 'report':S.rep={kind:t.dataset.kind,id};modal('<h2>Report this '+E(t.dataset.kind)+'</h2>'+['Spam','Harassment or bullying','Inappropriate content','Something else'].map(x=>'<button class="btn ghost" style="margin:0 0 8px;width:100%" data-act="dorep" data-id="'+x+'">'+x+'</button>').join('')+'<button class="btn ghost sm" data-act="close">Cancel</button>');break;
 case 'dorep':r=C.report(S.rep.kind,S.rep.id,id);closeModal();toast(r.ok?'Reported. Thank you for keeping Ficars safe.':r.error);break;
 case 'block':if(confirm("Block this person? You will no longer see each other's posts or messages.")){r=C.block(id);S.v='feed';S.uid=null;refresh();toast('Blocked.')}break;
 case 'share':S.sp=id;modal('<h2>Share with</h2>'+peopleBtns('shareto')+'<button class="btn ghost sm" data-act="close">Cancel</button>');break;
 case 'shareto':r=C.share(S.sp,id);closeModal();toast(r.ok?'Sent.':r.error);refresh();break;
 case 'chat':S.v='chats';S.chat=id;S.uid=null;C.markRead(id);refresh();break;
 case 'back':S.chat=null;refresh();break;
 case 'newstory':modal('<h2>New story</h2><form data-form="story"><label>Text<textarea name="t" maxlength="140" rows="2"></textarea></label><label>Background<select name="bg">'+['Teal','Amber','Violet','Rose'].map((n,k)=>'<option value="'+k+'">'+n+'</option>').join('')+'</select></label><label>Photo (optional)<input type="file" name="img" accept="image/*"></label><div class="row"><button type="button" class="btn ghost" data-act="close">Cancel</button><button class="btn">Share story</button></div></form>');break;
 case 'story':viewStory(id);break;
 case 'edit':{const m=C.me();modal('<h2>Edit profile</h2><form data-form="edit"><label>Name<input name="name" maxlength="40" required value="'+E(m.name)+'"></label><label>Profile photo<input type="file" name="av" accept="image/*"></label><label>Cover photo<input type="file" name="cv" accept="image/*"></label><div class="row"><button type="button" class="btn ghost" data-act="close">Cancel</button><button class="btn">Save changes</button></div></form>');break}
 case 'forgot':S.auth='reset';authScreen();break;
 case 'resend':r=await C.resendVerify();toast(r.ok?'Verification email sent.':r.error);break;
 case 'checkv':toast(await C.checkVerified()?'Email verified. You can post now.':'Not verified yet. Open the link in your email first.');refresh();break;
 case 'logout':await C.logout();reset();authScreen();break;
 case 'delacc':if(confirm('Delete your account and everything you posted? This cannot be undone.')){r=await C.deleteAccount();if(r.ok){reset();authScreen()}else toast(r.error)}break;
 }});
document.addEventListener('submit',async e=>{e.preventDefault();const f=e.target,k=f.dataset.form,d=Object.fromEntries(new FormData(f));let r;
 if(k==='login'||k==='signup'){r=k==='login'?await C.login(d.email,d.pw):await C.signup(d.name,d.email,d.pw);if(!r.ok){$('#aerr').textContent=r.error;return}S.v='feed';refresh();return}
 if(k==='reset'){r=await C.resetPassword(d.email);if(r.ok){S.auth='in';authScreen();toast(r.message)}else $('#aerr').textContent=r.error;return}
 if(k==='comment'){r=C.comment(f.dataset.id,d.t);if(r.ok)D['c-'+f.dataset.id]='';else toast(r.error);refresh();return}
 if(k==='msg'){r=C.send(S.chat,d.t,'');if(r.ok)D.msg='';else toast(r.error);refresh();return}
 if(k==='story'){let img='';try{if(d.img&&d.img.size)img=await shrink(d.img,720)}catch(x){toast(x.message);return}
  r=C.addStory(d.t,d.bg,img);if(!r.ok){toast(r.error);return}closeModal();toast('Story shared. It disappears in 24 hours.');refresh();return}
 if(k==='edit'){let av='',cv='';try{if(d.av&&d.av.size)av=await shrink(d.av,256);if(d.cv&&d.cv.size)cv=await shrink(d.cv,900)}catch(x){toast(x.message);return}
  r=C.updateProfile({name:d.name,avatar:av,cover:cv});if(!r.ok){toast(r.error);return}closeModal();refresh()}});
document.addEventListener('change',async e=>{const el=e.target;if(el.id!=='pfile'&&el.id!=='mfile')return;const f=el.files[0];if(!f)return;
 try{const d=await shrink(f);if(el.id==='pfile'){S.pimg=d}else{const r=C.send(S.chat,'',d);if(!r.ok)toast(r.error)}refresh()}catch(x){toast(x.message)}});
document.addEventListener('input',e=>{const el=e.target;if(el.id==='q'){S.q=el.value;sr()}else if(el.dataset&&el.dataset.draft)D[el.dataset.draft]=el.value});
let th=null;try{th=localStorage.getItem('ficars_theme')}catch(e){}
setTheme(th||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'));
$('#app').innerHTML='<p class="empty">Loading…</p>';C.onError(toast);C.onChange(refresh);C.onReady(()=>{ready=true;refresh()});
if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
